# Codes modified from https://dl.acm.org/doi/10.1145/3459637.3481895

# Author: Kester Yew Chong Wong
# Institution: University College London
# Email: dtnvckw@ucl.ac.uk
# 2020 Audio Enhanced BERT - AudiBERT

from AudiBERTutils import getAudioFeatures, recordRun, pad_sequences, getIdentifier, getGender, getAudioStart, getAudioEnd, getPHQ, str2bool, runCount
import json
import traceback
import sys
import argparse
import torch
import torch.nn.functional as F
import torchaudio
import warnings
from pydub import AudioSegment
import torchaudio.transforms as T
import tempfile
from pydub import AudioSegment
from pydub.playback import play
warnings.filterwarnings('ignore')

# Default Configuration
MAX_LEN = 128
batch_size = 1
useAudio = False
useGender = False
VGGSeconds = 3
epochs = 10
logtodb = False
maxruns = 20 
modelName = "BERT_VGGISH_DUALSELFATTN"
save_model = False
numPaseFilters = 15
numVectors = 15
useLSTM = True
useLastVectors = False
db='./expResults/diskexperiments.db'




parser = argparse.ArgumentParser()
parser.add_argument("--epochs", type=int, help="Number of Epochs to train. Default=4")
parser.add_argument("--modelName", help="Model Name. Default=RNN")
parser.add_argument("--logtodb", type=str2bool, help="Log Run To DB. Default=True")
parser.add_argument("--useLSTM", type=str2bool, help="Use LSTM. Default=True")
parser.add_argument("--useGender", type=str2bool, help="Use useGender. Default=False")
parser.add_argument("--useAudio", type=str2bool, help="Use useAudio. Default=False")

parser.add_argument("--maxruns", type=int, help="Maximum number of runs for same configuraiton Default=50")

args = parser.parse_args()



if args.__dict__["epochs"]  is not None:
    epochs = args.__dict__["epochs"]
if args.__dict__["useGender"]  is not None:
    useGender = args.__dict__["useGender"]
if args.__dict__["useAudio"]  is not None:
    useAudio = args.__dict__["useAudio"]
if args.__dict__["modelName"]  is not None:
    modelName = args.__dict__["modelName"] 
if args.__dict__["logtodb"]  is not None:
    logtodb = args.__dict__["logtodb"] 
if args.__dict__["useLSTM"]  is not None:
    useLSTM = args.__dict__["useLSTM"]     
if args.__dict__["maxruns"]  is not None:
    maxruns = args.__dict__["maxruns"]   

typeOfTask = modelName

print(typeOfTask)


configuration = {
    'MAX_LEN':MAX_LEN,
    'batch_size':batch_size,
    'model': modelName,
    'useAudio':useAudio,
    'useGender':useGender,
    'epochs':epochs,
    'typeOfTask': typeOfTask,
    'numPaseFilters': numPaseFilters,
    'numVectors': numVectors,
    'useLSTM': useLSTM,
    'useLastVectors': useLastVectors
}



short_configuration = ''
for configValue in configuration:
    short_configuration = short_configuration + str(configuration[configValue])

print(short_configuration)
results = {}

results['run_id'] = runCount(short_configuration,db=db)

if results['run_id'] > maxruns:
    print("Exiting. There are too many experiments with this configuraiton. Increase Max Run Count")
    sys.exit(0)
print(results['run_id'])

# INSERT DATA FILE
traindatafile = "./data/train.tsv"
testdatafile  = "./data/test.tsv"

if torch.cuda.is_available():      
    device = torch.device("cuda")

    print('There are %d GPU(s) available.' % torch.cuda.device_count())

    print('We will use the GPU:', torch.cuda.get_device_name(0))
# If not...
else:
    print('No GPU available, using the CPU instead.')
    device = torch.device("cpu")


# In[2]:


#Data Exploration
import pandas as pd
import numpy as np


df = pd.read_csv(traindatafile, delimiter='\t', header=None, names=['index', 'label','sentence', 'audio_features', 'time_feature'])
print('Number of training sentences: {:,}\n'.format(df.shape[0]))

sentences = df.sentence.values
labels = df.label.values
audio = df.audio_features.values 
time = df.time_feature.values
unique_labels = np.unique(labels)
num_unique_labels = len(unique_labels)
print(f"Number of unique labels in train data: {num_unique_labels}; ({unique_labels})")

train_identifiers = []
gender_list = []
score_list = []
train_StartTime = []
train_EndTime = []

# Audio Feature Exploration
for feature_string in audio:
    identifier = getIdentifier(feature_string)
    train_identifiers.append(identifier)
    gender_list.append([float(getGender(identifier))])
    score_list.append([float(getPHQ(identifier))])

for feature_string in time:
    identifier = getAudioStart(feature_string)
    train_StartTime.append(identifier)
    
    identifier = getAudioEnd(feature_string)
    train_EndTime.append(identifier)

configuration["train_identifiers"] = train_identifiers
configuration["train_StartTime"] = train_StartTime
configuration["train_EndTime"] = train_EndTime

num_gender_features = 1
if not useGender:
    num_gender_features = 0


if 'BERT' in modelName.upper():
    from transformers import BertTokenizer
    # Load the BERT tokenizer.
    print('Loading BERT tokenizer...')
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased', do_lower_case=True)

if 'BERT' in modelName.upper():
    # Tokenize all of the sentences and map the tokens to thier word IDs.
    input_ids = []
    attention_masks = []
    line = 0

    for sentence in sentences:
        encoded_sent = tokenizer.encode_plus(
                        sentence,                     
                        add_special_tokens = True, 
                        padding= 'max_length',
                        max_length=128,
                        return_attention_mask = True,   
                        return_tensors = 'pt'  
                   )

        input_ids.append(encoded_sent['input_ids'])
        attention_masks.append(encoded_sent['attention_mask'])
        line = line + 1



import torch


if 'BERT' in modelName.upper():
    traindataset_inputs = torch.cat(input_ids, dim=0)
    traindataset_masks = torch.cat(attention_masks, dim=0)


traindataset_labels = torch.tensor(labels) 

traindataset_gender = torch.tensor(gender_list) 
traindataset_identifiers = torch.tensor([int(id) for id in train_identifiers]) 
traindataset_StartTime = torch.tensor([float(id) for id in train_StartTime]) 
traindataset_EndTime = torch.tensor([float(id) for id in train_EndTime]) 


from torch.utils.data import TensorDataset, DataLoader, RandomSampler, SequentialSampler, random_split

# Create the DataLoader for our training set.
if 'BERT' in modelName.upper():
    dataset = TensorDataset(traindataset_inputs, traindataset_masks, traindataset_labels,traindataset_gender,traindataset_identifiers,traindataset_StartTime,traindataset_EndTime)
    # Calculate the number of samples to include in each set.
    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size

    torch.manual_seed(42)
    # Divide the dataset by randomly selecting samples.
    train_data, val_data = random_split(dataset, [train_size, val_size])

else:
    dataset = TensorDataset(traindataset_labels, traindataset_gender,traindataset_identifiers,traindataset_StartTime,traindataset_EndTime)
    # Calculate the number of samples to include in each set.
    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size

    torch.manual_seed(42)
    # Divide the dataset by randomly selecting samples.
    train_data, val_data = random_split(dataset, [train_size, val_size])

train_dataloader = DataLoader(train_data, sampler = RandomSampler(train_data), batch_size=batch_size)
prediction_dataloader = DataLoader(val_data, sampler = SequentialSampler(val_data), batch_size = batch_size)

from torch.optim import AdamW
from transformers import BertForSequenceClassification, BertConfig, BertModel, BertPreTrainedModel
from torch import nn
from torch.nn import CrossEntropyLoss, MSELoss
import torch
from torch.autograd import Variable
from torch.nn import functional as F
dependencies = ['torch', 'numpy', 'resampy', 'soundfile']
badIDs = []

if modelName.upper() == 'BERT':
    from torch.optim import AdamW
    from transformers import BertForSequenceClassification, BertConfig, BertModel, BertPreTrainedModel
else:
    from torch.optim import AdamW
from torch import nn
from torch.nn import CrossEntropyLoss, MSELoss
import torch
from torch.autograd import Variable
from torch.nn import functional as F
dependencies = ['torch', 'numpy', 'resampy', 'soundfile']
badIDs = []

if modelName.upper() == 'BERT_WAV2VEC_DUALSELFATTN':
    from torchvggish.vggish import VGGish
    from models.BERTWav2VecDualAttention import BERTWav2VecDualAttention
    
    # Using preloaded BERT
    print("using Huggingface: wongyck/categories_BERT_epoch_7")
    model = BERTWav2VecDualAttention.from_pretrained(
        "wongyck/categories_BERT_epoch_7", # Use the best performing epch of BERT MODEL
        num_labels = 13, # The number of output labels--2 for binary classification.
                        # You can increase this for multi-class tasks.   
        output_attentions = False, # Whether the model returns attentions weights.
        output_hidden_states = False, # Whether the model returns all hidden-states.
        num_gender_features = num_gender_features,
        ignore_mismatched_sizes=True)      

# Tell pytorch to run this model on the GPU.
model.cuda()    
    
    
params = list(model.named_parameters())
modelDescription = str(model)
configuration['modelDescription'] = modelDescription

from torch.optim import AdamW
optimizer = AdamW(model.parameters(),
                  lr = 2e-5, 
                  eps = 1e-8
                )


from transformers import get_linear_schedule_with_warmup
total_steps = len(train_dataloader) * epochs

scheduler = get_linear_schedule_with_warmup(optimizer, 
                                            num_warmup_steps = 0, # Default value in run_glue.py
                                            num_training_steps = total_steps)


import numpy as np

def flat_accuracy(preds, labels):
    pred_flat = np.argmax(preds, axis=1).flatten()
    labels_flat = labels.flatten()
    return np.sum(pred_flat == labels_flat) / len(labels_flat)

import time
import datetime

def format_time(elapsed):
    elapsed_rounded = int(round((elapsed)))
    return str(datetime.timedelta(seconds=elapsed_rounded))

from sklearn.metrics import matthews_corrcoef, f1_score, auc, recall_score, precision_score, accuracy_score, roc_auc_score


import random
import pickle
import os

seed_val = 42

random.seed(seed_val)
np.random.seed(seed_val)
torch.manual_seed(seed_val)
torch.cuda.manual_seed_all(seed_val)

avg_train_loss_values = []
avg_validation_loss_values = []
mcc_values = []
fone_values = []
acc_values = []
data_train = []
data_test = []

def create_empty_pickle(file_path):
    print(f'Continue to append in existing file: {file_path}')
    if not os.path.exists(file_path):
        print(f'File does not exist. Creating new file: {file_path}')
        with open(file_path, "wb") as f:
            pickle.dump([], f)


# Define the model checkpoint directory
model_dir = "#DIRECTORY#"


saved_epochs = []
for filename in os.listdir(model_dir):
    if filename.startswith("model_epoch_") and filename.endswith(".model"):
        try:
            epoch_num = int(filename.split("_")[-1].split(".")[0])  # Extract epoch number
            saved_epochs.append(epoch_num)
        except ValueError:
            continue 

# Determine the starting epoch
if saved_epochs:
    latest_epoch = max(saved_epochs)  # Get the latest saved epoch
    print(f"Already obtain model for epoch {latest_epoch}. Resume training from epoch {latest_epoch + 1}")
else:
    latest_epoch = 0  # Start from 0 if no saved models found
    print("No saved models found. Not loading any models.")

# Start training from the determined epoch
for epoch_i in range(latest_epoch + 1, epochs+1):  # Train up to epoch 5
    
    # Create a dynamic file path
    training_pickle_file_path = f"#DIRECTORY#_{epoch_i}.pkl"
    create_empty_pickle(training_pickle_file_path)
    testing_pickle_file_path = f"#DIRECTORY#_{epoch_i}.pkl"
    create_empty_pickle(testing_pickle_file_path)
    results_file_path = f"#DIRECTORY#_{epoch_i}.pkl"
    create_empty_pickle(results_file_path)
    
    # Load the saved model checkpoint if resuming from a previous epoch
    if epoch_i > 1:
        model_path = f"{model_dir}/model_epoch_{epoch_i-1}.model"
        if os.path.exists(model_path):
            model.load_state_dict(torch.load(model_path))
            print(f"Loaded model from {model_path}")
        else:
            print(f"Checkpoint for epoch {epoch_i} not found.")

    # ========================================
    #               Training
    # ========================================
    
    # Perform one full pass over the training set.

    print("")
    print("/////////////////////////////////////////")
    print('................Training................')
    print('======== Epoch {:} / {:} ========'.format(epoch_i, epochs))


    # Measure how long the training epoch takes.
    t0 = time.time()

    # Reset the total loss for this epoch.
    training_total_loss = 0
    validation_total_loss = 0

    model.train()

    # For each batch of training data...
    for step, batch in enumerate(train_dataloader):

        # Progress update every 40 batches.
        if step % 40 == 0 and not step == 0:
            # Calculate elapsed time in minutes.
            elapsed = format_time(time.time() - t0)
            
            # Report progress.
            print('  Batch {:>5,}  of  {:>5,}.    Elapsed: {:}.'.format(step, len(train_dataloader), elapsed))

        if 'BERT' in modelName.upper():           
            b_input_ids = batch[0].to(device)
            b_input_mask = batch[1].to(device)
            b_labels = batch[2].to(device)
            b_gender = batch[3].to(device)

            start_sec = batch[5].cpu().numpy()[0]
            end_sec = batch[6].cpu().numpy()[0]
            print(f"**********************SENTENCE {step+1} of {len(train_dataloader)}******************************")
            #Define Audio Data Directory
            audio_folder_path = "#DIRECTORY#"
            audio_file_path = str(audio_folder_path+str(batch[4].cpu().numpy()[0])+'.wav')
            print(f'{audio_file_path}')
            waveform, sample_rate = torchaudio.load(audio_file_path)
            if waveform.shape[0] > 1:
              waveform = waveform.mean(dim=0, keepdim=True)
            
            # Resample if necessary to 16 kHz
            TARGET_SAMPLE_RATE = 16000
            if sample_rate != TARGET_SAMPLE_RATE:
              waveform = T.Resample(sample_rate, TARGET_SAMPLE_RATE)(waveform)

            start_sample = int(start_sec * TARGET_SAMPLE_RATE)
            end_sample = int(end_sec * TARGET_SAMPLE_RATE)
            segment = waveform[:, start_sample:end_sample]
            
            # Save the segment to a temporary file
            temp_file = audio_folder_path+'temp.wav'
            torchaudio.save(temp_file, segment, TARGET_SAMPLE_RATE)
            wav_file = temp_file

        model.zero_grad()        


        if 'BERT' in modelName.upper():           
            outputs = model(b_input_ids, 
                        b_gender,
                        wav_file,
                        token_type_ids=None, 
                        attention_mask=b_input_mask, 
                        labels=b_labels)
        else:
            outputs = model(b_gender,wav_file,labels=b_labels)


        loss = outputs[0]


        training_total_loss += loss.item()

        # Perform a backward pass to calculate the gradients.
        loss.backward()

        # Clip the norm of the gradients to 1.0.
        # This is to help prevent the "exploding gradients" problem.
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)

        # Update parameters and take a step using the computed gradient.
        optimizer.step()

        # Update the learning rate.
        scheduler.step()

        # Save the variables to the pickle file
        step_data = {
        "epoch": epoch_i,
        "step": step+1,
        "b_input_ids": b_input_ids.cpu().numpy(),
        "audio_file_path": audio_file_path,
        "pooled_attention":outputs[2],
        "logits": outputs[1],
        "loss": loss.item(),
        "total loss": training_total_loss
    }

        data_train.append(step_data)

    # Calculate the average loss over the training data.
    avg_train_loss = training_total_loss / len(train_dataloader)            
    
    # Store the loss value for plotting the learning curve.
    avg_train_loss_values.append(avg_train_loss)

    print("")
    print("  Average training loss: {0:.2f}".format(avg_train_loss))
    print("  Training epoch took: {:}".format(format_time(time.time() - t0)))
    
    print("")
    print("/////////////////////////////////////////")
    print('................Testing................')
    # Prediction on test set

    # Put model in evaluation mode
    model.eval()

    # Tracking variables 
    predictions , true_labels = [], []

    predict_count = 0
    # Predict 
    for batch in prediction_dataloader:
        # Add batch to GPU
        batch = tuple(t.to(device) for t in batch)
        print(f"**********************SENTENCE {predict_count+1} of {len(prediction_dataloader)}******************************")

        # Unpack the inputs from our dataloader
        if 'BERT' in modelName.upper():           
            b_input_ids, b_input_mask, b_labels, b_gender, b_identifier, start_sec, end_sec = batch
            #Define Audio Data Directory
            audio_folder_path = "#DIRECTORY#"
            audio_file_path = str(audio_folder_path+str(b_identifier.cpu().numpy()[0])+'.wav')
            print(f'{audio_file_path}')
            waveform, sample_rate = torchaudio.load(audio_file_path)
            if waveform.shape[0] > 1:
              waveform = waveform.mean(dim=0, keepdim=True)
            
            # Resample if necessary to 16 kHz
            TARGET_SAMPLE_RATE = 16000
            if sample_rate != TARGET_SAMPLE_RATE:
              waveform = T.Resample(sample_rate, TARGET_SAMPLE_RATE)(waveform)
            print(f'Start time (sec): {start_sec}')
            print(f'End time (sec): {end_sec}')
            start_sample = int(start_sec * TARGET_SAMPLE_RATE)
            end_sample = int(end_sec * TARGET_SAMPLE_RATE)
            segment = waveform[:, start_sample:end_sample]
            
            # Save the segment to a temporary file
            temp_file = audio_folder_path+'temp2.wav'
            torchaudio.save(temp_file, segment, TARGET_SAMPLE_RATE)
            wav_file = temp_file

        with torch.no_grad():
          # Forward pass, calculate logit predictions
            if 'BERT' in modelName.upper():
                outputs = model(b_input_ids, 
                        b_gender,
                        wav_file,
                        token_type_ids=None, 
                        attention_mask=b_input_mask, 
                        labels=b_labels)
            else:
                outputs = model(b_gender,wav_file)

        loss = outputs[0]

        validation_total_loss += loss.item()

        # Save the variables to the pickle file
        step_data = {
        "epoch": epoch_i,
        "step": predict_count+1,
        "b_input_ids": b_input_ids.cpu().numpy(),
        "audio_file_path": audio_file_path,
        "pooled_attention":outputs[2],
        "logits": outputs[1],
        "loss": loss.item(),
        "total loss": validation_total_loss
    }

        logits = outputs[1]

        data_test.append(step_data)
        
        # Move logits and labels to CPU
        logits = logits.detach().cpu().numpy()
        label_ids = b_labels.to('cpu').numpy()

        # Store predictions and true labels
        predictions.append(logits)
        true_labels.append(label_ids)
        predict_count += 1

    # Calculate the average loss over the training data.
    avg_validation_loss = validation_total_loss / len(prediction_dataloader)            
    
    # Store the loss value for plotting the learning curve.
    avg_validation_loss_values.append(avg_validation_loss)

    print("")
    print("  Average validation loss: {0:.2f}".format(avg_validation_loss))
    
    print("")
    print('!!!!!!!!!!!!!!!!!!!!DONE!!!!!!!!!!!!!!!!!!!!')

    # Combine the predictions for each batch into a single list of 0s and 1s.
    flat_predictions = [item for sublist in predictions for item in sublist]
    flat_predictions = np.argmax(flat_predictions, axis=1).flatten()

    # Combine the correct labels for each batch into a single list.
    flat_true_labels = [item for sublist in true_labels for item in sublist]
    
    # Calculate the MCC
    mcc = matthews_corrcoef(flat_true_labels, flat_predictions)
    trueProbability = []
    falseProbability = []

    for prediction in predictions:
        falseProbability.append(float(prediction[0][0]))
        trueProbability.append(float(prediction[0][1]))
    
    f1 = f1_score(flat_true_labels, flat_predictions, average='weighted')
    recall = recall_score(flat_true_labels, flat_predictions, average='weighted')
    precision = precision_score(flat_true_labels, flat_predictions, average='weighted')
    acc = accuracy_score(flat_true_labels, flat_predictions)
    results['true_labels'] = list(map(int, flat_true_labels))
    results['predictions'] = (list(map(int, flat_predictions)))
    results['falseProbability'] = (list(map(float, falseProbability)))
    results['trueProbability'] = (list(map(float, trueProbability)))

    
    results['mcc'] = mcc
    results['f1'] = f1
    results['precision'] = precision
    results['recall'] = recall
    results['acc'] = acc
    results['epoch'] = epoch_i
    results['training_loss'] = avg_train_loss_values
    results['validation_loss'] = avg_validation_loss_values

    print(results)

    results_df = {
    'epoch': epoch_i,
    'average training loss': avg_train_loss_values,
    'average validation loss': avg_validation_loss_values,
    'true_labels': list(map(int, flat_true_labels)),
    'predictions': list(map(int, flat_predictions)),
    'falseProbability': list(map(float, falseProbability)),
    'trueProbability': list(map(float, trueProbability)),
    'mcc': mcc,
    'f1': f1,
    'precision': precision,
    'recall': recall,
    'acc': acc 
    }
    
    with open(training_pickle_file_path, "rb") as f:
          data = pickle.load(f)
    data.append(data_train)
    with open(training_pickle_file_path, "wb") as f:
          pickle.dump(data, f)

    with open(testing_pickle_file_path, "rb") as f:
          data = pickle.load(f)
    data.append(data_test)
    with open(testing_pickle_file_path, "wb") as f:
          pickle.dump(data, f)

    with open(results_file_path, "rb") as f:
      data = pickle.load(f)
    data.append(results_df)
    with open(results_file_path, "wb") as f:
          pickle.dump(data, f)

    #Save model in directory
    torch.save(model.state_dict(), f'#DIRECTORY#_{epoch_i}.model')
    print(f'Model for epoch {epoch_i} saved at #DIRECTORY#_{epoch_i}.model')