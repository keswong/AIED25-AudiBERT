from __future__ import absolute_import, division, print_function
import csv
import logging
import os
import sys
import numpy as np
import six
from io import open
import json
import sqlite3
import pandas as pd
from scipy.io import wavfile # get the api


def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

def executeQuery(query,db='./expResults/toto_results_12112020.db'):
    try:
        conn = sqlite3.connect(db, timeout=60)
        c = conn.cursor()
        result = c.execute(query)
        records = result.fetchall()
        #print(records[0][0])
        conn.commit()
        conn.close()
        return records
    except sqlite3.Error as er:
        print('SQLite error: %s' % (' '.join(er.args)))
        print("Exception class is: ", er.__class__)
        print('SQLite traceback: ')
        exc_type, exc_value, exc_tb = sys.exc_info()
        print(traceback.format_exception(exc_type, exc_value, exc_tb))
        conn.close()
        return "error"

def getExperimentalSetupID(configuration,short_configuration,tags="",db='./expResults/toto_results_12112020.db'):
    configuration_text = json.dumps(configuration)
    short_configuration_text = json.dumps(short_configuration)
    getid_query = "select experiment_id from experimentalSetup where short_configuration = '"+short_configuration_text+"';"
    insertid_query = "INSERT INTO experimentalSetup(configuration,short_configuration) VALUES ('"+configuration_text+"','"+short_configuration_text+"');"
    result = executeQuery(getid_query,db=db)
    if len(result) == 0:
        executeQuery(insertid_query,db=db)
        result = executeQuery(getid_query,db=db)
        experiment_id = result[0][0]
    else:
        experiment_id = result[0][0]
    return experiment_id


def recordRun(configuration,short_configuration,results,tags="",db='./expResults/toto_results_12112020.db'):
    experiment_id = getExperimentalSetupID(configuration,short_configuration,db=db)
    results_text = json.dumps(results)
    #Configuration Values
    if "useAudio" in configuration:   
        audio = int(configuration['useAudio'])
    else:
        audio = 1   

    if "useGender" in configuration:   
        gender = int(configuration['useAudio'])
    else:
        gender = 1  
        
   
    
    model= configuration['model']
    task = configuration['typeOfTask']
    question = configuration['question']
    
    #Result Values
    run_id = results['run_id']
    epoch = results['epoch']
    mcc = results['mcc']
    fone = results['f1']
    precision = results['precision']
    recall = results['recall']
    acc = results['acc']
    if "auc" in configuration:   
        auc = int(configuration['auc'])
    else:
        auc = 0     

    
    insertrun_query = "INSERT INTO experimentalRuns(run_id, experiment_id, results, audio, gender, model, task, epoch, mcc, fone, precision, recall, acc, auc, tags, question, short_configuration) VALUES ("+str(run_id)+","+str(experiment_id)+",'"+results_text+"'," + str(audio) + "," + str(gender) + ",'" + model + "','" + task + "'," + str(epoch) + "," + str(mcc) + "," + str(fone) + "," + str(precision) + "," + str(recall) + "," + str(acc) + "," + str(auc) + ",'" + tags  + "','" + question + "','" + short_configuration + "');"
    print(insertrun_query)
    result = executeQuery(insertrun_query,db=db)

def runCount(short_configuration,db='./expResults/toto_results_12112020.db'):
    count_query = "select count(DISTINCT run_id) from experimentalRuns where short_configuration = '" + str(short_configuration) + "';"
    result = executeQuery(count_query,db=db)
    return int(result[0][0])

    
def getGender(ParticipantID, genderFile = './daicphq8andgender.csv'):
    # Load the dataset into a pandas dataframe.
    df = pd.read_csv(genderFile, delimiter=',')
    gender = df.loc[df['ParticipantID'] == int(ParticipantID)]['Gender']
    return int(gender.item())

def getPHQ(ParticipantID, phqfile = './daicphq8andgender.csv'):
    # Load the dataset into a pandas dataframe.
    df = pd.read_csv(phqfile, delimiter=',')
    score = df.loc[df['ParticipantID'] == int(ParticipantID)]['score']
    return int(score.item())

def getAudioFeatures(audioFeatures, fullListOfFeatures = "./featureList.csv",selectedFeatures = "./featurecache_DAIC.json", getAll=False):
    audioFeatures = audioFeatures[2:-2].split(",")
    audioFeatures = audioFeatures[2:]
    audioFeatures = [float(i) for i in audioFeatures]
    #Load Full List of Featurs
    with open(fullListOfFeatures) as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        featureList = next(reader) 

    #Load Feature Subset
    with open(selectedFeatures) as f:
        featureSubset = json.load(f)
    #Generate Feature Subset Indeces
    subFeatureIndeces = []
    for feature in featureList:
        if feature in featureSubset:
            subFeatureIndeces.append(featureList.index(feature))
    if getAll:
        return audioFeatures
    else:
        return [audioFeatures[i] for i in subFeatureIndeces]

def getIdentifier(audioFeatures):
    audioFeatures = audioFeatures[2:-2].split(",")
    #print(audioFeatures[0])
    return audioFeatures[0]

def getAudioStart(audioFeatures):
    audioFeatures = audioFeatures[2:-2].split(",")
    #print(audioFeatures[0])
    return audioFeatures[0]

def getAudioEnd(audioFeatures):
    audioFeatures = audioFeatures[2:-2].split(",")
    #print(audioFeatures[1])
    return audioFeatures[1]

# Keras pad_sequences that will work on turing

def pad_sequences(sequences, maxlen=None, dtype='int32',
                  padding='pre', truncating='pre', value=0.):
    """Pads sequences to the same length.
    This function transforms a list of
    `num_samples` sequences (lists of integers)
    into a 2D Numpy array of shape `(num_samples, num_timesteps)`.
    `num_timesteps` is either the `maxlen` argument if provided,
    or the length of the longest sequence otherwise.
    Sequences that are shorter than `num_timesteps`
    are padded with `value` at the beginning or the end
    if padding='post.
    Sequences longer than `num_timesteps` are truncated
    so that they fit the desired length.
    The position where padding or truncation happens is determined by
    the arguments `padding` and `truncating`, respectively.
    Pre-padding is the default.
    # Arguments
        sequences: List of lists, where each element is a sequence.
        maxlen: Int, maximum length of all sequences.
        dtype: Type of the output sequences.
            To pad sequences with variable length strings, you can use `object`.
        padding: String, 'pre' or 'post':
            pad either before or after each sequence.
        truncating: String, 'pre' or 'post':
            remove values from sequences larger than
            `maxlen`, either at the beginning or at the end of the sequences.
        value: Float or String, padding value.
    # Returns
        x: Numpy array with shape `(len(sequences), maxlen)`
    # Raises
        ValueError: In case of invalid values for `truncating` or `padding`,
            or in case of invalid shape for a `sequences` entry.
    """
    if not hasattr(sequences, '__len__'):
        raise ValueError('`sequences` must be iterable.')
    num_samples = len(sequences)

    lengths = []
    sample_shape = ()
    flag = True

    # take the sample shape from the first non empty sequence
    # checking for consistency in the main loop below.

    for x in sequences:
        try:
            lengths.append(len(x))
            if flag and len(x):
                sample_shape = np.asarray(x).shape[1:]
                flag = False
        except TypeError:
            raise ValueError('`sequences` must be a list of iterables. '
                             'Found non-iterable: ' + str(x))

    if maxlen is None:
        maxlen = np.max(lengths)

    is_dtype_str = np.issubdtype(dtype, np.str_) or np.issubdtype(dtype, np.unicode_)
    if isinstance(value, six.string_types) and dtype != object and not is_dtype_str:
        raise ValueError("`dtype` {} is not compatible with `value`'s type: {}\n"
                         "You should set `dtype=object` for variable length strings."
                         .format(dtype, type(value)))

    x = np.full((num_samples, maxlen) + sample_shape, value, dtype=dtype)
    for idx, s in enumerate(sequences):
        if not len(s):
            continue  # empty list/array was found
        if truncating == 'pre':
            trunc = s[-maxlen:]
        elif truncating == 'post':
            trunc = s[:maxlen]
        else:
            raise ValueError('Truncating type "%s" '
                             'not understood' % truncating)

        # check `trunc` has expected shape
        trunc = np.asarray(trunc, dtype=dtype)
        if trunc.shape[1:] != sample_shape:
            raise ValueError('Shape of sample %s of sequence at position %s '
                             'is different from expected shape %s' %
                             (trunc.shape[1:], idx, sample_shape))

        if padding == 'post':
            x[idx, :len(trunc)] = trunc
        elif padding == 'pre':
            x[idx, -len(trunc):] = trunc
        else:
            raise ValueError('Padding type "%s" not understood' % padding)
    return x

def resultsTable(experiments,listoftasks,questions,gender,isMean = True,bestof=5,appendAverage=False,appendMax=False,roundingPrecision=3,sortby='fone',ignoreGender=False,averageOnly=False,includeStdev=True):
    if averageOnly:
        appendAverage=True
    roundingPrecision
    listOfStringsToReplace = []
    resultsTable = pd.DataFrame(index = listoftasks, columns = questions) 
    resultsTableNumeric = pd.DataFrame(index = listoftasks, columns = questions) 
    numModelExperiments = 20
    for question in questions:
        #print(question)
        if not ignoreGender:
            questionExperiments = experiments.loc[(experiments['question'] == question) & (experiments['gender'] == gender)]
        else:
            questionExperiments = experiments.loc[(experiments['question'] == question)]
        #print(questionExperiments)
        bestOfEpochIDX = questionExperiments.groupby(['experiment_id','run_id'])[sortby].transform(max) == questionExperiments[sortby]
        expboe = questionExperiments[bestOfEpochIDX]
        for task in listoftasks:
            expSubset = expboe.loc[(expboe['task'] == task)]
            if not expSubset.empty:
                result_values = {}
                expSubset = expSubset.sort_values(by=[sortby],ascending = False)
                if isMean:
                    expSubset = expSubset.head(numModelExperiments)
                    result_values[sortby] = round(expSubset[sortby].mean(),roundingPrecision)
                    result_values['stdev'] = round(expSubset[sortby].std(),roundingPrecision)
                else:
                    expSubset = expSubset.head(bestof)
                    result_values[sortby] = round(expSubset[sortby].mean(),roundingPrecision)
                    result_values['stdev'] = round(expSubset[sortby].std(),roundingPrecision)
                if includeStdev:
                    result_str = str(result_values[sortby]) + "+" + str(result_values['stdev'])
                else:
                    result_str = str(result_values[sortby])
                resultsTable.at[task, question] = result_str
                resultsTableNumeric.at[task, question] = result_values[sortby]
    if appendAverage:
        resultsTable['Avg'] = round(resultsTableNumeric.mean(axis=1),roundingPrecision)
        resultsTableNumeric['Avg'] = round(resultsTableNumeric.mean(axis=1),roundingPrecision)
        max_value = round(resultsTableNumeric['Avg'].max(),roundingPrecision)
        print(max_value)
        maxLocations = resultsTableNumeric.loc[resultsTableNumeric['Avg'] == max_value]
        indexOfMaxLocation = resultsTable.index.get_loc(maxLocations.index[0])
        listOfStringsToReplace.append(str(resultsTable['Avg'][indexOfMaxLocation]))
        boldValuesTable = resultsTable.iloc[indexOfMaxLocation]
    if appendMax:
        resultsTable['Max'] = round(resultsTableNumeric.max(axis=1),roundingPrecision)
        resultsTableNumeric['Max'] = round(resultsTableNumeric.max(axis=1),roundingPrecision)
        max_value = round(resultsTableNumeric['Max'].max(),roundingPrecision)
        print(max_value)
        maxLocations = resultsTableNumeric.loc[resultsTableNumeric['Max'] == max_value]
        indexOfMaxLocation = resultsTable.index.get_loc(maxLocations.index[0])
        listOfStringsToReplace.append(str(resultsTable['Max'][indexOfMaxLocation]))
        boldValuesTable = resultsTable.iloc[indexOfMaxLocation] 
        
    for question in questions:
        max_value = round(resultsTableNumeric[question].max(),roundingPrecision)
        maxLocations = resultsTableNumeric.loc[resultsTableNumeric[question] == max_value]
        indexOfMaxLocation = resultsTable.index.get_loc(maxLocations.index[0])
        listOfStringsToReplace.append(resultsTable[question][indexOfMaxLocation])

    # Keep this for operations on the whole avg winning method
    #for value in boldValuesTable:
    #    listOfStringsToReplace.append(str(value))
    #print(resultsTable.iloc[indexOfMaxLocation])
    #print(resultsTable[:,-1:].max())
    #print(resultsTableNumeric)
    #print(resultsTableNumeric.mean(axis=1))
    if averageOnly:
        return resultsTable['Avg ' + sortby], listOfStringsToReplace
    else:
        return resultsTable, listOfStringsToReplace

def perf_measure(y_actual, y_hat):
    TP = 0
    FP = 0
    TN = 0
    FN = 0
    for i in range(len(y_hat)): 
        if y_actual[i]==y_hat[i]==1:
            TP += 1
        if y_hat[i]==1 and y_actual[i]!=y_hat[i]:
            FP += 1
        if y_actual[i]==y_hat[i]==0:
            TN += 1
        if y_hat[i]==0 and y_actual[i]!=y_hat[i]:
            FN += 1
    return(TP, FP, TN, FN)

def recall(TP, FP, TN, FN):
    if (TP + FN) == 0:
        return 0
    else:
        return TP / (TP + FN)

def precision(TP, FP, TN, FN):
    if (TP + FP) == 0:
        return 0
    else:
        return TP / (TP + FP)

def f1(TP, FP, TN, FN):
    return 2 * TP / (2*TP + FP + FN)

def latexBold(plainText):
    return "\\textbf{" + str(plainText) + "}"

def latexItalic(plainText):
    return "\\textit{" + str(plainText) + "}"


def prepQuotes(argValue):
    if isinstance(argValue, str):
        return "'" + str(argValue) + "'"
    else:
        return str(argValue)

def getPersonalFrequencies(wav_file,segmentdiv,numFrequencies):
    '''
    extract list of dominant frequencies in sliding windows of duration defined by 'step' for a wav files and return an list
    he list will contain a range of *filtered* frequencies corresponding to sliding windows within each wav file
    '''
    rate, data = wavfile.read(wav_file)
    #get dominating frequencies in sliding windows of 200ms
    step = int(rate/segmentdiv) #this could change but usually 16K/5 = 3200 sampling points every 1/5 sec 
    window_frequencies = []
    for i in range(0,int(len(data)),step):
        ft = np.fft.fft(data[i:i+step])
        freqs = np.fft.fftfreq(len(ft)) #fftq tells you the frequencies associated with the coefficients
        imax = np.argmax(np.abs(ft))
        freq = freqs[imax]
        freq_in_hz = abs(freq *rate)
        window_frequencies.append(freq_in_hz)
        filtered_frequencies = [f for f in window_frequencies if 20<f<300 and not 46<f<66] 
        # I see noise at 50Hz and 60Hz. See plots below
    return filtered_frequencies[:numFrequencies] + [0]*(numFrequencies-len(filtered_frequencies)) 

def stratified_sample_df(df, col, n_samples):
    n = min(n_samples, df[col].value_counts().min())
    df_ = df.groupby(col).apply(lambda x: x.sample(n))
    df_.index = df_.index.droplevel(0)
    return df_



def is_primitive(thing):
    primitive = (int, str, bool, float)
    return isinstance(thing, primitive)

def label_score(row,cutoff):
    if is_primitive(row):
        if row >= cutoff:
            return 1
        else:
            return 0
    else:
        if row['score'] >= cutoff :
            return 1
        else:
            return 0
    
    
def loadDAICWOZ(question):
    # Daic-Woz Question Data Import
    #Provide Dataset Location
    traindatafile = "./data/"+question+"/train.tsv"
    testdatafile  = "./data/"+question+"/dev.tsv"
    # Load The Train Dataset
    train_dataset = pd.read_csv(traindatafile, delimiter='\t', header=None, names=['index', 'label', 'label_notes', 'sentence', 'audio_features'])
    test_dataset = pd.read_csv(testdatafile, delimiter='\t', header=None, names=['index', 'label', 'label_notes', 'sentence', 'audio_features'])
    # Join these datasets. We will perform random sampling at each itertion for a more robust
    # confidence interval generation. #The train set was upsampled. We'll undo that in a few. 
    # Why do this? It is easier to get unique identifiers in pandas than have two distinct pipelines, or store
    # a double set of data. This makes some of the operations uniform. 
    dataset = pd.concat([train_dataset,test_dataset])
    #We have no use for index, and label notes in this implementation:
    del dataset['index']
    del dataset['label_notes']
    #But we do need gender and actual DAIC ID. Time for some cool lambda flexing
    dataset['identifier'] = dataset.apply(lambda x: getIdentifier(x['audio_features']), axis=1)
    dataset['gender'] = dataset.apply(lambda x: getGender(x['identifier']), axis=1)
    dataset['score'] = dataset.apply(lambda x: getPHQ(x['identifier']), axis=1)
    dataset['audio_features']
    #Now we can drop the duplicates and have the original dataset cleaned up for the question.
    #Sometimes too much ado for nothing is a good thing
    dataset = dataset.drop_duplicates('identifier')
    return dataset

def loadEMUOpen(cutoff):
    # EMUOpen import
    #Provide Dataset Location
    datasetFile = "./EmuMoodable/emuopen.csv"
    # Load The Train Dataset
    dataset = pd.read_csv(datasetFile, delimiter=',', header=None,skiprows=1, names=['identifier', 'gender', 'score', 'gad7', 'sentence'])
    # Join these datasets. We will perform random sampling at each itertion for a more robust
    # confidence interval generation. #The train set was upsampled. We'll undo that in a few. 
    # Why do this? It is easier to get unique identifiers in pandas than have two distinct pipelines, or store
    # a double set of data. This makes some of the operations uniform. 
    #We have no use for index, and label notes in this implementation:
    #But we do need gender and actual DAIC ID. Time for some cool lambda flexing
    dataset['label'] = dataset.apply(lambda x: label_score(float(x['score']),cutoff), axis=1)
    dataset['sentence'] = dataset['sentence'].fillna('empty')
    dataset['sentence'] = dataset.apply(lambda x: x['sentence'].lower(), axis=1)
    return dataset