*Please be advised that all data here are randomly generated and are for demonstration purpose only*

# Installing AudiBERT

## Environment

Before installing AudiBERT, you would need to ensure:
- Your pip has a version higher than 19.0, otherwise the requirement that
  `tensorflow > 2.0.0` could not be satisfied for failed to find the package.
- CUDA 11.0 is installed, and the file `libcudart.so.11.0` is in one of the
  PATH's as specified by `LD_LIBRARY_PATH`.
- SciPy requires your installation of BLAS and LAPACK, and set environment
  variables as below. Check out [official documentation](https://docs.scipy.org/doc/scipy/reference/building/linux.html) for more information.
  ```bash
  export BLAS=/path/to/libblas.so
  export LAPACK=/path/to/liblapack.so
  ```
  - You could also use `sudo apt-get install libblas-dev liblapack-dev` on Debian-based systems with root permission.

## Packages

The required packages are listed in `requirements.txt`, and could be installed
with `pip install -r requirements.txt`. You may set `TMPDIR` environment variable
to specify temporary building directory for pip.

## Preprocess Data

Run the followings to generate data in data/.

```bash
ipython kernel install --name "trenv" --user
papermill dataPrep.ipynb dataPrepOut.ipynb
```

## Create Databases

Please `cd` to folder `expResults` and run the followings:

```bash
./createDb.sh diskexperiments.db
./createDb.sh kdd_all_daic.db
```

## Usage

## Jupyter
trenv
