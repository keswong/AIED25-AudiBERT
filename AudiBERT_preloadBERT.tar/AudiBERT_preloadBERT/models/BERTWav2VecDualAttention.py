# Codes modified from https://dl.acm.org/doi/10.1145/3459637.3481895

# Author: Kester Yew Chong Wong
# Institution: University College London
# Email: dtnvckw@ucl.ac.uk
# 2020 Audio Enhanced BERT - AudiBERT

from torch.optim import AdamW
from transformers import BertForSequenceClassification, BertConfig, BertModel, BertPreTrainedModel
from torch import nn
from torch.nn import CrossEntropyLoss, MSELoss
import torch
from torch.autograd import Variable
from torch.nn import functional as F
import torchaudio

from transformers import Wav2Vec2FeatureExtractor, Wav2Vec2Model
from torch.nn.functional import pad
from transformers import Wav2Vec2Config
import os

class BERTWav2VecDualAttention(BertPreTrainedModel):
    def __init__(self, config,num_gender_features):
        super().__init__(config)
        if(num_gender_features == 0):
            self.useGender = False
        else:
            self.useGender = True  
                                    
        n_layers = 1     
        #BERT Configuration    
        self.num_labels = self.config.num_labels
        self.bert = BertModel(config)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)    
        embedding_dim = config.hidden_size
        self.bert_lstm_hidden_size = 128
        self.lstm_bert = nn.LSTM(embedding_dim, self.bert_lstm_hidden_size, n_layers,batch_first=True, bidirectional=True)
        #----------------------
         
        model_name = "facebook/wav2vec2-base-960h"
        self.wav2vec = Wav2Vec2FeatureExtractor.from_pretrained(model_name)
        self.wav2vec_model = Wav2Vec2Model.from_pretrained(model_name)
        input_dim = 768 #1024
        hidden_dim = 128
        self.lstm_audio = nn.LSTM(input_dim, hidden_dim, n_layers, batch_first=True, bidirectional=True)
        #----------------------
        
        #BERT Self Attention Layer
        self.W_s1_bert = nn.Linear(2*self.bert_lstm_hidden_size, 350)
        self.W_s2_bert = nn.Linear(350, 30)
        #----------------------

        #Audio Self Attention Layer
        self.W_s1_audio = nn.Linear(2*hidden_dim, 350)
        self.W_s2_audio = nn.Linear(350, 30)
        self.num_seconds = -1 # if > 0 then use num seconds, else use all audio
        #----------------------

        print(f"Number of num_gender_features: {num_gender_features}")
        self.fc_layer = nn.Linear(30*2*self.bert_lstm_hidden_size+30*2*hidden_dim+num_gender_features, 2000)
        self.classifier = nn.Linear(2000, self.num_labels)
        
        self.init_weights()
    def attention_net_bert(self, lstm_output):
        attn_weight_matrix_bert = self.W_s2_bert(F.tanh(self.W_s1_bert(lstm_output)))
        attn_weight_matrix_bert = attn_weight_matrix_bert.permute(0, 2, 1)
        attn_weight_matrix_bert = F.softmax(attn_weight_matrix_bert, dim=2)
        return attn_weight_matrix_bert
    
    def audio_attention_net(self, lstm_output_audio):
        attn_weight_matrix_audio = self.W_s2_audio(F.tanh(self.W_s1_audio(lstm_output_audio)))
        attn_weight_matrix_audio = attn_weight_matrix_audio.permute(0, 2, 1)
        attn_weight_matrix_audio = F.softmax(attn_weight_matrix_audio, dim=2)
        return attn_weight_matrix_audio       
    
    def forward(self, input_ids, gender_ids, wav_file, token_type_ids=None, attention_mask=None, labels=None,
                position_ids=None, head_mask=None, fs=None):
        """ BERT Text Embeddings """
        outputs = self.bert(input_ids, position_ids=position_ids, token_type_ids=token_type_ids,
                            attention_mask=attention_mask, head_mask=head_mask)
        last_hidden_state, pooled_output = outputs
        lstm_input = outputs.last_hidden_state

        lstm_out_bert, (ht, ct) = self.lstm_bert(torch.tensor(lstm_input))
        bert_lstm_hidden_output = ht[-1]  
        
        attn_weight_matrix_bert = self.attention_net_bert(lstm_out_bert)
        hidden_matrix_bert = torch.bmm(attn_weight_matrix_bert, lstm_out_bert)

        bert_attention_output = hidden_matrix_bert.view(-1, hidden_matrix_bert.size()[1]*hidden_matrix_bert.size()[2])
        """ End Of BERT Text Embeddings """ 
        print("===========A. CHECK FOR NAN in BERT TENSORS================")
        if torch.isnan(lstm_input).any() or torch.isinf(lstm_input).any():
          print("lstm_input contains NaN or Inf values!")
        if torch.isnan(lstm_out_bert).any() or torch.isinf(lstm_out_bert).any():
          print("lstm_out_bert contains NaN or Inf values!")
        if torch.isnan(attn_weight_matrix_bert).any() or torch.isinf(attn_weight_matrix_bert).any():
          print("attn_weight_matrix_bert contains NaN or Inf values!")
        if torch.isnan(hidden_matrix_bert).any() or torch.isinf(hidden_matrix_bert).any():
          print("hidden_matrix_bert contains NaN or Inf values!")
        if torch.isnan(bert_attention_output).any() or torch.isinf(bert_attention_output).any():
          print("bert_attention_output contains NaN or Inf values!")
        print("========================================================")

        """ Wav2Vec Audio Embeddings """
  
        waveform, sample_rate = torchaudio.load(wav_file)
        os.remove(wav_file)
        print(f"{wav_file} used and removed")
  
        audio_features = self.wav2vec(waveform, return_tensors="pt", sampling_rate=sample_rate)

        input_values = audio_features['input_values']
        input_values = input_values.squeeze(1)#Squeeze the extra channel dimension
        
  
        input_values = input_values.to(self.wav2vec_model.device)

        desired_length = 3500  # or whatever length works for your model

        if input_values.size(1) < desired_length:
          input_values_padded = pad(input_values, (0, desired_length - input_values.size(1)))

        else:
          input_values_padded = input_values  # No padding needed if already of the desired length
        
        audio_outputs = self.wav2vec_model(input_values_padded)        
        lstm_audio_input = audio_outputs.last_hidden_state
        lstm_out_audio, (ht, ct) = self.lstm_audio(torch.tensor(lstm_audio_input))

        hidden_audio_output = ht[-1]
        attn_weight_matrix_audio = self.audio_attention_net(lstm_out_audio)
        hidden_matrix_audio = torch.bmm(attn_weight_matrix_audio, lstm_out_audio)

        audio_attention_output = hidden_matrix_audio.view(-1, hidden_matrix_audio.size()[1]*hidden_matrix_audio.size()[2])
    
        """ End Of Wav2Vec Audio Embeddings """

        print("===========B. CHECK FOR NAN in AUDIO TENSORS================")
        if torch.isnan(input_values).any() or torch.isinf(input_values).any():
          print("input_values contains NaN or Inf values!")
        if torch.isnan(lstm_audio_input).any() or torch.isinf(lstm_audio_input).any():
          print("lstm_audio_input contains NaN or Inf values!")
        if torch.isnan(attn_weight_matrix_audio).any() or torch.isinf(attn_weight_matrix_audio).any():
          print("attn_weight_matrix_audio contains NaN or Inf values!")
        if torch.isnan(hidden_matrix_audio).any() or torch.isinf(hidden_matrix_audio).any():
          print("hidden_matrix_audio contains NaN or Inf values!")
        if torch.isnan(audio_attention_output).any() or torch.isinf(audio_attention_output).any():
          print("audio_attention_output contains NaN or Inf values!")
        print("=========================================================")


        pooled_attention = torch.cat((bert_attention_output,audio_attention_output),1)

        outputs = (pooled_attention,) +outputs[2:]
        print("Pooled Attention")
        print(pooled_attention)
        if self.useGender:
            print("Gender included in attention layer")
            logits = self.classifier(self.fc_layer(torch.cat((pooled_attention,gender_ids),1)))
        else:
            print("Gender not included in attention layer")
            logits = self.classifier(self.fc_layer(pooled_attention))
        
        outputs = (logits,) + outputs  # add hidden states and attention if they are here
        

        if labels is not None:
            if self.num_labels == 2:
                loss_fct = MSELoss()

                # Ensure logits and labels are both Float
                logits = logits.view(-1).to(torch.float32)  # Ensure logits are Float
                labels = labels.view(-1).to(torch.float32)  # Convert labels to Float

                loss = loss_fct(logits, labels)
            else:
                loss_fct = CrossEntropyLoss()
                loss = loss_fct(logits.view(-1, self.num_labels), labels.view(-1))
            outputs = (loss,) + outputs

        return outputs