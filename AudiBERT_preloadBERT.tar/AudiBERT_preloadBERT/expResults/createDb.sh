#!/bin/bash
sqlite3 $1 < tables.sql
