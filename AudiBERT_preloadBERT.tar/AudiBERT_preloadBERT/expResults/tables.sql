CREATE TABLE experimentalRuns (id INTEGER PRIMARY KEY AUTOINCREMENT, 
run_id INTEGER,
experiment_id INTEGER not NULL, 
results TEXT not NULL, 
audio TEXT, 
gender TEXT,
model TEXT,
task TEXT,
tags TEXT,
question TEXT,
epoch int, 
mcc REAL,
fone REAL,
precision REAL,
recall REAL,
acc REAL,
auc REAL,
runtime TIMESTAMP  DEFAULT CURRENT_TIMESTAMP
, short_configuration TEXT, tokens int);

CREATE TABLE experimentalSetup (experiment_id INTEGER PRIMARY KEY AUTOINCREMENT, configuration TEXT not NULL, tags TEXT , short_configuration TEXT);
